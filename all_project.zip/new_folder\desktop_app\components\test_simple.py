class TestClass:
    def __init__(self):
        self.test = "working"

print("File loaded successfully")
